//
//  Person.h
//  compar
//
//  Created by jinxin on 16/3/24.
//  Copyright © 2016年 zhaixingzhi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject
/**此界面的主题名*/
@property(nonatomic,copy)NSString * name;
/**此界面的主题名*/
@property(nonatomic,copy)NSNumber * age;
/**
 *  name
 */
@property (nonatomic, copy) NSString *title;

@end
