//
//  AppDelegate.h
//  Search
//
//  Created by 翟兴智 on 2016/11/7.
//  Copyright © 2016年 翟兴智. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

