//
//  Person.m
//  sound
//
//  Created by Alan on 16/8/22.
//  Copyright © 2016年 zhaixingzhi. All rights reserved.
//

#import "People.h"

@implementation People
- (void)setValue:(id)value forUndefinedKey:(NSString *)key{}
- (NSString *)description {
    return [NSString stringWithFormat:@"name ==%@ %@ -->age == %@", self.firstName, self.lastName,self.age];
}
@end
