//
//  ViewController.m
//  Search
//
//  Created by 翟兴智 on 2016/11/7.
//  Copyright © 2016年 翟兴智. All rights reserved.
//

#import "ViewController.h"
#import "People.h"


@interface ViewController ()
@property (nonatomic, strong) NSMutableArray *dataArray;
@end

@implementation ViewController

- (NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self load];
    UITextField *textField = [[UITextField alloc]initWithFrame:CGRectMake(0, 50, 300, 50)];
    textField.backgroundColor = [UIColor magentaColor];
    [self.view addSubview:textField];
    [textField addTarget: self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    // Do any additional setup after loading the view, typically from a nib.
}
- (void)load
{
    
    NSArray *firstNames = @[ @"Alice", @"Bob", @"Charlie",@"Zhai", @"Quentin" ];
    NSArray *lastNames = @[ @"Smith", @"Jones", @"Smith",@"Alan", @"Alberts" ];
    NSArray *ages = @[@24, @27,@33,@24, @31 ];
    
    NSMutableArray *people = [NSMutableArray array];
    [firstNames enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        People *person = [[People alloc] init];
        person.firstName = [firstNames objectAtIndex:idx];
        person.lastName = [lastNames objectAtIndex:idx];
        person.age = [ages objectAtIndex:idx];
        [people addObject:person];
    }];
    self.dataArray = people;
    //yes从小到大排序，no从大到小排序
    NSSortDescriptor *firstNameSortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"firstName"
                                                                              ascending:YES
                                                                               selector:@selector(localizedStandardCompare:)];
    NSSortDescriptor *lastNameSortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"lastName"
                                                                             ascending:YES
                                                                              selector:@selector(localizedStandardCompare:)];
    NSSortDescriptor *ageSortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"age"
                                                                        ascending:YES];
    
    NSLog(@"By age: %@", [people sortedArrayUsingDescriptors:@[ageSortDescriptor]]);
    
    
    NSLog(@"By first name: %@", [people sortedArrayUsingDescriptors:@[firstNameSortDescriptor]]);
    
    
    NSLog(@"By last name, first name: %@", [people sortedArrayUsingDescriptors:@[lastNameSortDescriptor, firstNameSortDescriptor]]);
    
    //如果针对多个条件进行排序的话，那就在数组中添加多个就行了，优先性根据数组中的前后决定
    NSSortDescriptor *age = [NSSortDescriptor sortDescriptorWithKey:@"age" ascending:NO];
    NSSortDescriptor *first = [NSSortDescriptor sortDescriptorWithKey:@"firstName" ascending:YES];
    NSLog(@"By age and firstName == %@",[people sortedArrayUsingDescriptors:@[age,first]]);
    
}


- (void)textFieldDidChange:(UITextField *)text
{
    NSPredicate *result = [NSPredicate predicateWithFormat:@"firstName CONTAINS[cd] %@",text.text];
    NSPredicate *result1 = [NSPredicate predicateWithFormat:@"lastName CONTAINS[cd] %@",text.text];
    
    
    NSPredicate *predicate = [NSCompoundPredicate orPredicateWithSubpredicates:@[result, result1]];

    NSArray *array = [NSArray arrayWithArray:[self.dataArray filteredArrayUsingPredicate:result]];
    NSArray *array1 = [NSArray arrayWithArray:[self.dataArray filteredArrayUsingPredicate:result1]];
    NSArray *array2 = [NSArray arrayWithArray:[self.dataArray filteredArrayUsingPredicate:predicate]];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
