//
//  Person.h
//  sound
//
//  Created by Alan on 16/8/22.
//  Copyright © 2016年 zhaixingzhi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface People : NSObject
@property (copy, nonatomic)NSString *firstName;
@property (copy, nonatomic)NSString *lastName;
@property (copy, nonatomic)NSNumber *age;
@end
