//
//  Person.m
//  compar
//
//  Created by jinxin on 16/3/24.
//  Copyright © 2016年 zhaixingzhi. All rights reserved.
//

#import "Person.h"

@implementation Person
-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{}


-(NSComparisonResult)comparePerson:(Person *)person{
    //默认按年龄排序
    NSComparisonResult result = [person.age compare:self.age];//注意:基本数据类型要进行数据转换
    //如果年龄一样，就按照名字排序
    if (result == NSOrderedSame) {
        result = [self.name compare:person.name];
    }
    return result;
}

@end
